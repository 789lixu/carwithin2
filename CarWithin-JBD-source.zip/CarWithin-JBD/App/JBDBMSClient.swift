import CoreBluetooth
import Foundation
import UIKit

/// Read-only 嘉佰达 (JBD) telemetry, confined to the main queue. A peripheral is
/// selected explicitly and remembered by CoreBluetooth UUID, never by strongest
/// signal. Each poll cycle asks for register 0x03 (basic telemetry) and then
/// register 0x04 (cell voltages); nothing is ever written to the protection board.
final class JBDBMSClient: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    struct Device {
        let id: UUID
        let name: String
        let rssi: Int
    }

    /// JBD modules expose FF00 with FF01 notifications and FF02 writes.
    private static let service = CBUUID(string: "FF00")
    private static let notifyCharacteristic = CBUUID(string: "FF01")
    private static let writeCharacteristic = CBUUID(string: "FF02")
    static let keySelectedID = "jbdBMSPeripheral"
    static let keySelectedName = "jbdBMSName"

    /// Preferences saved by the ANT build are adopted once so re-signing the app
    /// does not drop the user's device, card layout or enable switch.
    static func migrateLegacyDefaults(_ defaults: UserDefaults = .standard) {
        let pairs = ["antBMSPeripheral": keySelectedID, "antBMSName": keySelectedName,
                     "antBMSEnabled": "jbdBMSEnabled", "antBMSCardFields": "jbdBMSCardFields",
                     "antBMSCardSize": "jbdBMSCardSize", "antBMSPosition": "jbdBMSPosition",
                     "antBMSCardBackground": "jbdBMSCardBackground"]
        for (legacy, current) in pairs where defaults.object(forKey: current) == nil {
            guard let value = defaults.object(forKey: legacy) else { continue }
            defaults.set(value, forKey: current)
        }
    }

    private let defaults: UserDefaults
    private var central: CBCentralManager?
    private var peripheral: CBPeripheral?
    private var discovered: [UUID: CBPeripheral] = [:]
    private var found: [UUID: Device] = [:]
    private var writer: CBCharacteristic?
    private var reader: CBCharacteristic?
    private var parser = JBDBMSProtocol()
    private var assembler = JBDBMSAssembler()
    private var expectedCommand = JBDBMSAssembler.basicInfoCommand
    private var lastWriteAt: TimeInterval = 0
    private var lastFrameAt: TimeInterval?
    private var timer: Timer?
    private var reconnectWork: DispatchWorkItem?
    private var scanTimeout: DispatchWorkItem?
    private var enabled = false
    private var scanRequested = false
    private var writePending = false
    private var connectedAt: TimeInterval?
    private var retryDelay: TimeInterval = 2
    private var disconnecting = Set<UUID>()
    private(set) var status = "未连接 BMS"
    private(set) var sample: BMSSample?
    var onChange: (() -> Void)?
    var onLog: ((String) -> Void)?

    var devices: [Device] { found.values.sorted { $0.rssi > $1.rssi } }
    var selectedID: UUID? { defaults.string(forKey: Self.keySelectedID).flatMap(UUID.init(uuidString:)) }
    var selectedName: String { defaults.string(forKey: Self.keySelectedName) ?? "未选择" }
    var freshReading: BMSReading? {
        guard let sample, sample.isFresh(at: ProcessInfo.processInfo.systemUptime) else { return nil }
        return sample.reading
    }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        super.init()
        Self.migrateLegacyDefaults(defaults)
    }

    deinit {
        timer?.invalidate(); reconnectWork?.cancel(); scanTimeout?.cancel()
    }

    func start() {
        guard !enabled else { return }
        enabled = true
        if central == nil {
            central = CBCentralManager(delegate: self, queue: .main)
        } else if central?.state == .poweredOn {
            connectRememberedOrScan()
        } else {
            update("等待蓝牙可用")
        }
        let timer = Timer(timeInterval: 1, repeats: true) { [weak self] _ in self?.tick() }
        self.timer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    func stop() {
        enabled = false; scanRequested = false
        timer?.invalidate(); timer = nil
        reconnectWork?.cancel(); reconnectWork = nil
        scanTimeout?.cancel(); scanTimeout = nil
        central?.stopScan()
        clearConnection()
        update("未连接 BMS")
    }

    func scan() {
        guard enabled else { return }
        scanRequested = true
        found.removeAll(); discovered.removeAll()
        beginScan()
    }

    func select(_ id: UUID) {
        guard enabled, let device = found[id] else { return }
        defaults.set(id.uuidString, forKey: Self.keySelectedID)
        defaults.set(device.name, forKey: Self.keySelectedName)
        reconnectWork?.cancel(); reconnectWork = nil
        central?.stopScan(); scanRequested = false
        scanTimeout?.cancel(); scanTimeout = nil
        clearConnection()
        retryDelay = 2
        connectRememberedOrScan()
    }

    func forget() {
        clearConnection()
        reconnectWork?.cancel(); reconnectWork = nil
        defaults.removeObject(forKey: Self.keySelectedID)
        defaults.removeObject(forKey: Self.keySelectedName)
        if enabled { scan() } else { update("未选择 BMS") }
    }

    /// Restores a previously chosen device from a vehicle profile, never a scan guess.
    func restoreSelection(id: UUID?, name: String?) {
        clearConnection()
        reconnectWork?.cancel(); reconnectWork = nil
        if let id {
            defaults.set(id.uuidString, forKey: Self.keySelectedID)
            defaults.set(name ?? "JBD BMS", forKey: Self.keySelectedName)
        } else {
            defaults.removeObject(forKey: Self.keySelectedID)
            defaults.removeObject(forKey: Self.keySelectedName)
        }
        if enabled { connectRememberedOrScan() } else { update("已恢复车辆 BMS 配置") }
    }

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state != .poweredOn { disconnecting.removeAll() }
        guard enabled else { return }
        if central.state == .poweredOn {
            if scanRequested { beginScan() } else { connectRememberedOrScan() }
        } else {
            reconnectWork?.cancel(); reconnectWork = nil
            scanTimeout?.cancel(); scanTimeout = nil
            clearConnection()
            disconnecting.removeAll()
            switch central.state {
            case .unauthorized: update("蓝牙权限未允许，请在系统设置中开启")
            case .poweredOff: update("蓝牙已关闭")
            case .unsupported: update("此设备不支持 BMS 蓝牙读取")
            default: update("等待蓝牙可用")
            }
        }
    }

    private func connectRememberedOrScan() {
        guard enabled, let central, central.state == .poweredOn, peripheral == nil else { return }
        guard let id = selectedID else { scan(); return }
        guard !disconnecting.contains(id) else { scheduleReconnect(); return }
        if let target = discovered[id] ?? central.retrievePeripherals(withIdentifiers: [id]).first {
            central.stopScan()
            peripheral = target; target.delegate = self
            connectedAt = ProcessInfo.processInfo.systemUptime
            update("正在连接 \(selectedName)…")
            central.connect(target, options: nil)
        } else {
            scanRequested = true
            beginScan()
        }
    }

    private func beginScan() {
        guard enabled, let central, central.state == .poweredOn else { return }
        scanTimeout?.cancel()
        // Known JBD service filtering also supports iOS background discovery.
        central.scanForPeripherals(withServices: UIApplication.shared.applicationState == .active ? nil : [Self.service], options: nil)
        update("正在扫描嘉佰达 JBD BMS…")
        let timeout = DispatchWorkItem { [weak self] in
            guard let self, self.enabled else { return }
            self.central?.stopScan(); self.scanRequested = false
            if self.peripheral == nil {
                self.update(self.found.isEmpty ? "未找到嘉佰达 BMS，请确认保护板蓝牙已开启" : "请选择自己的嘉佰达 BMS")
                if self.selectedID != nil { self.scheduleReconnect() }
            }
        }
        scanTimeout = timeout
        DispatchQueue.main.asyncAfter(deadline: .now() + 15, execute: timeout)
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        guard enabled else { return }
        let name = advertisementData[CBAdvertisementDataLocalNameKey] as? String ?? peripheral.name ?? "未命名 FF00 设备"
        let services = advertisementData[CBAdvertisementDataServiceUUIDsKey] as? [CBUUID] ?? []
        guard name.uppercased().hasPrefix("JBD") || services.contains(Self.service)
                || peripheral.identifier == selectedID else { return }
        // Service FF00 is shared by many BLE boards; picking a candidate never
        // confirms JBD support. Only a checksum-valid 0x03 frame does that.
        discovered[peripheral.identifier] = peripheral
        found[peripheral.identifier] = Device(id: peripheral.identifier, name: name, rssi: RSSI.intValue)
        onChange?()
        if selectedID == peripheral.identifier, self.peripheral == nil { connectRememberedOrScan() }
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        guard enabled, peripheral === self.peripheral else { return }
        update("已连接蓝牙，正在发现 JBD 通道…")
        connectedAt = ProcessInfo.processInfo.systemUptime
        peripheral.discoverServices([Self.service])
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        if disconnecting.remove(peripheral.identifier) != nil {
            if enabled, self.peripheral == nil { scheduleReconnect() }
            return
        }
        disconnected(peripheral, reason: "BMS 连接失败")
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        if disconnecting.remove(peripheral.identifier) != nil {
            if enabled, self.peripheral == nil { scheduleReconnect() }
            return
        }
        disconnected(peripheral, reason: "BMS 已断开")
    }

    private func disconnected(_ device: CBPeripheral, reason: String) {
        guard device === peripheral else { return }
        clearConnection()
        guard enabled else { return }
        update(reason + "，等待重连")
        scheduleReconnect()
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard peripheral === self.peripheral, enabled else { return }
        guard error == nil, let service = peripheral.services?.first(where: { $0.uuid == Self.service }) else {
            failConnection("设备没有可用的 JBD FF00 服务"); return
        }
        peripheral.discoverCharacteristics(nil, for: service)
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard peripheral === self.peripheral, enabled else { return }
        let candidates = service.characteristics ?? []
        func writable(_ characteristic: CBCharacteristic) -> Bool {
            characteristic.properties.contains(.write) || characteristic.properties.contains(.writeWithoutResponse)
        }
        func notifiable(_ characteristic: CBCharacteristic) -> Bool {
            characteristic.properties.contains(.notify) || characteristic.properties.contains(.indicate)
        }
        // Prefer the documented FF02 write / FF01 notify pair, but tolerate boards
        // that only expose one characteristic per direction.
        let writer = candidates.first { $0.uuid == Self.writeCharacteristic && writable($0) }
            ?? candidates.first { writable($0) }
        let reader = candidates.first { $0.uuid == Self.notifyCharacteristic && notifiable($0) }
            ?? candidates.first { notifiable($0) }
        guard error == nil, let writer, let reader else {
            failConnection("设备没有可用的 JBD FF01/FF02 收发通道"); return
        }
        self.writer = writer; self.reader = reader
        peripheral.setNotifyValue(true, for: reader)
        update("正在订阅 JBD 实时数据…")
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        guard peripheral === self.peripheral, characteristic === reader, enabled else { return }
        guard error == nil, characteristic.isNotifying else { failConnection("BMS 通知订阅失败"); return }
        update("等待首个校验有效的 JBD 实时帧…")
        poll()
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard peripheral === self.peripheral, characteristic === reader, enabled,
              error == nil, let data = characteristic.value else { return }
        for frame in parser.append(data) {
            lastFrameAt = ProcessInfo.processInfo.systemUptime
            if frame.command == JBDBMSAssembler.basicInfoCommand {
                expectedCommand = JBDBMSAssembler.cellInfoCommand
            } else if frame.command == JBDBMSAssembler.cellInfoCommand {
                expectedCommand = JBDBMSAssembler.basicInfoCommand
            }
            guard let reading = assembler.consume(frame) else { continue }
            sample = BMSSample(reading: reading, uptime: ProcessInfo.processInfo.systemUptime)
            retryDelay = 2
            update("JBD 实时数据已连接")
            onChange?()
        }
        poll()
    }

    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        guard peripheral === self.peripheral, characteristic === writer else { return }
        writePending = false
        if let error { failConnection("BMS 读取请求失败：\(error.localizedDescription)") }
    }

    private func tick() {
        guard enabled else { return }
        let now = ProcessInfo.processInfo.systemUptime
        if let sample, !sample.isFresh(at: now) {
            update("BMS 数据已过期，等待恢复")
        }
        if let connectedAt, now - (sample?.uptime ?? connectedAt) > 12 {
            failConnection("BMS 未返回有效实时数据，正在重连")
            return
        }
        // A board that never answers 0x04 must not stall the cycle.
        if expectedCommand != JBDBMSAssembler.basicInfoCommand, now - (lastFrameAt ?? now) > 2.5 {
            expectedCommand = JBDBMSAssembler.basicInfoCommand
        }
        poll()
        onChange?()
    }

    /// Sends the next documented read-only query of the cycle. The two registers
    /// are requested back to back: 0x03 first, 0x04 as soon as 0x03 came back.
    private func poll() {
        guard enabled, let peripheral, peripheral.state == .connected,
              let writer, reader?.isNotifying == true, !writePending else { return }
        let now = ProcessInfo.processInfo.systemUptime
        guard now - lastWriteAt >= 0.05 else { return }
        let type: CBCharacteristicWriteType = writer.properties.contains(.write) ? .withResponse : .withoutResponse
        if type == .withoutResponse, !peripheral.canSendWriteWithoutResponse { return }
        let request: Data
        switch expectedCommand {
        case JBDBMSAssembler.cellInfoCommand: request = JBDBMSProtocol.cellInfoRequest
        default:
            expectedCommand = JBDBMSAssembler.basicInfoCommand
            request = JBDBMSProtocol.basicInfoRequest
        }
        writePending = type == .withResponse
        lastWriteAt = now
        peripheral.writeValue(request, for: writer, type: type)
    }

    private func failConnection(_ message: String) {
        clearConnection()
        update(message)
        scheduleReconnect()
    }

    private func clearConnection() {
        let previous = peripheral
        peripheral = nil; writer = nil; reader = nil; sample = nil
        connectedAt = nil; writePending = false; lastFrameAt = nil
        parser = JBDBMSProtocol(); assembler = JBDBMSAssembler()
        expectedCommand = JBDBMSAssembler.basicInfoCommand
        previous?.delegate = nil
        if let previous, previous.state != .disconnected {
            disconnecting.insert(previous.identifier)
            central?.cancelPeripheralConnection(previous)
        }
    }

    private func scheduleReconnect() {
        guard enabled, selectedID != nil, reconnectWork == nil, central?.state == .poweredOn else { return }
        let retry = DispatchWorkItem { [weak self] in
            guard let self else { return }
            self.reconnectWork = nil
            self.connectRememberedOrScan()
        }
        reconnectWork = retry
        DispatchQueue.main.asyncAfter(deadline: .now() + retryDelay, execute: retry)
        retryDelay = min(retryDelay * 2, 30)
    }

    private func update(_ text: String) {
        if text != status { status = text; onLog?(text) }
        onChange?()
    }
}
